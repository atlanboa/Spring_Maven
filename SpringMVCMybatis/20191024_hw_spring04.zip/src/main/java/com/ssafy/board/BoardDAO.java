package com.ssafy.board;

import java.util.List;

public interface BoardDAO {

	void insert(Board vo) throws Exception;
	List<Board> selectAll() throws Exception;
	Board selectOne(String no) throws Exception;
	
}
